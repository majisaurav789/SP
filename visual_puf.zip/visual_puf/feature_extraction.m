function [feature_out,label_core,label_process] = feature_extraction(label_raw,T,C)

    % Base-Image: Getting the Luminosity of the label:
    Ibase                        = imresize(label_raw,[T,T]);
    Ibase                        = double(Ibase)./double(rgb2gray(Ibase));
    Ibase                        = uint8(255*Ibase);                       

    % Constast_Image: Getting High-Contrast label by Histogram Equalising & Thresholding:
    Icontrast                               = histeq(rgb2gray(Ibase));
    Iindex                                  = Icontrast;
    Icontrast(((Iindex>=0  )&(Iindex<64) )) = 0;
    Icontrast(((Iindex>=64 )&(Iindex<128))) = 64;
    Icontrast(((Iindex>=128)&(Iindex<192))) = 192;
    Icontrast(((Iindex>=192)&(Iindex<255))) = 255;

    % Superimposing the Images to get the processed label:
    label_process = uint8(((0.5*Ibase)+(0.5*Icontrast)));

    % Extracting the core of the label_core:
    label_core = rgb2gray(label_process(((T/2)-(C/2)+1):((T/2)+(C/2)),((T/2)-(C/2)+1):((T/2)+(C/2)),:));

    % Segregating & avergaing the core of label_puf to obtain feature_out:
    R           = 8;
    K           = (C/R);
    feature_out = zeros(R*R,1);
    for x = 1:R
        for y = 1:R
            Mxy                    = label_core(((x-1)*K+1):(x*K),((y-1)*K+1):(y*K),:);
            feature_out((x-1)*R+y) = mean(Mxy,'all');
        end
    end

end