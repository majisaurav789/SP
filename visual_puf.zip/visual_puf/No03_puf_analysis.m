clear; clc;
% This script analyzes the PUF responses based on chosen metrics of
% uniformity, uniqueness, repeatability and randomness.

load('puf_response/PUF_30x2.mat');
SEED      = 30;

%% UNIFORMITY STUDY OF PUF CODES:
bit_uniformity = zeros(SEED,1);
for x = 1:SEED
    bit_uniformity(x) = sum(puf_response(x,1,:))/size(puf_response,3);
end
fprintf("Average Bit Uniformity = %1.3f\n",mean(bit_uniformity));
clear edges x;

%% UNIQUENESS STUDY OF PUF CODES:
interHD_corr = zeros(SEED,SEED);
for x = 1:SEED
    for y = 1:SEED
        A = puf_response(x,1,:);
        B = puf_response(y,1,:);
        interHD_corr(x,y) = sum(abs(A-B));
    end
end
interHD_corr = interHD_corr/size(puf_response,3);

%% REPEATIBILITY STUDY OF PUF CODES:
intraHD_corr = zeros(SEED,SEED);
for x = 1:SEED
    for y = 1:SEED
        A = puf_response(x,1,:);
        B = puf_response(y,2,:);
        intraHD_corr(x,y) = sum(abs(A-B));
    end
end
intraHD_corr = intraHD_corr/size(puf_response,3);

%% PLOTTING THE FIGURES:
figure(3);
subplot(2,2,1); hold on; box on; grid on;
xlim([0,1]); xticks(0:0.5:1); xlabel('Bit Uniformity');
ylim([0,12]); yticks(0:3:12); ylabel('Counts');
edges = 0:0.02:1;
histogram(bit_uniformity,edges,'FaceColor',[246 178 172]/255);
title('PUF Bit Uniformity');

subplot(2,2,2);
box on; hold on; grid on; 
xlim([0 1]); ylim([0 80]);
edges = 0:0.02:1;

% Histogram of intraHD:
intraHD = zeros(1,SEED);
for x = 1:SEED
    intraHD(x) = intraHD_corr(x,x);
end
histogram(intraHD,edges,'FaceColor',[159 234 246]/255); 
h1 = histfit(intraHD);
h1(1).FaceColor = 'none';
h1(1).EdgeColor = 'none';
h1(2).Color = [16 90 215]/255;

% Histogram of interHD:
interHD = zeros(1,SEED*(SEED-1)/2);
count   = 1;
for x = 1:SEED
    for y = (x+1):SEED
        interHD(count) = interHD_corr(x,y);
        count = count + 1;
    end
end
histogram(interHD,edges,'FaceColor',[246 178 172]/255);
h2 = histfit(interHD);
h2(1).FaceColor = 'none';
h2(1).EdgeColor = 'none';
h2(2).Color = [148 17 0]/255;
title('Histogram of Hamming Distances');
xlabel('Hamming Distance');
ylabel('Counts');

interHD_avg = mean(interHD);
interHD_std = std(interHD);
intraHD_avg = mean(intraHD);
intraHD_std = std(intraHD);

fprintf("PUF intra-HD Mean: %0.3f Standard Deviation: %0.3f\n",intraHD_avg,intraHD_std);
fprintf("PUF inter-HD Mean: %0.3f Standard Deviation: %0.3f\n",interHD_avg,interHD_std);
clear count edges h1 h2 interHD interHD_avg interHD_std intraHD intraHD_avg intraHD_std;

subplot(2,2,3);
image(interHD_corr,'CDataMapping','scaled');
colormap('pink');
colorbar;
caxis([0 1]);
xticks(0:10:SEED);
xlabel('Seeds');
yticks(0:10:SEED);
ylabel('Seeds');
title('PUF Uniqueness');
clear x y A B;


subplot(2,2,4);
image(intraHD_corr,'CDataMapping','scaled');
colormap('pink');
colorbar;
caxis([0 1]);
xticks(0:10:SEED);
xlabel('Seeds');
yticks(0:10:SEED);
ylabel('Seeds');
title('PUF Repeatibility');
clear x y A B;


%% PRINTING THE PUF CODES FOR RANDOMNESS TEST:
% Paste the codes in Python for PUF Verification.
fprintf("\n\n#VISUAL %d PUF CODES (FOR %d SEEDS)\n",SEED,SEED);
fprintf("result = zeros((%d,8))\n",SEED)
for x = 1:SEED
    fprintf("puf = '");
    puf = squeeze(puf_response(x,1,:));
     for z = 1:size(puf,1)
        fprintf('%d',puf(z));
     end
     fprintf("'; ");
     fprintf(" result[%d] = test_nist(puf);\n",x-1);
end 
fprintf("print_nist_result(result)\n");  
clear puf x z;

