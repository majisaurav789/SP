clear; clc;
% This code processes the label images, stores the intermediate images in the folder "images" and generates the PUF features. 
SEED         = 30;
SCAN         = 2;

T            = 400; % Length / Width (in pixels) of label_refine.
C            = 280; % Length / Width (in pixels) of puf.
puf_features = zeros(64,1);

for seedno = 1:SEED
    for scanno = 1:SCAN
        label_raw_file        = strcat('label_image_in/IMG_',num2str(seedno,'%02d'),'_',num2str(scanno,'%d'),'_label_raw.JPG');
        label_raw             = imread(label_raw_file);

        [puf_features,label_puf,label_refine] = feature_extraction(label_raw,T,C);

        label_refine_file    = strcat('label_image_out/IMG_',num2str(seedno,'%02d'),'_',num2str(scanno,'%d'),'_label_refine.JPG');
        imwrite(label_refine,label_refine_file);

        label_puf_file       = strcat('label_image_out/IMG_',num2str(seedno,'%02d'),'_',num2str(scanno,'%d'),'_puf.JPG');
        imwrite(label_puf,label_puf_file);

        outfilename          = strcat('puf_features/puf_features_seed',num2str(seedno,'%02d'),'_scan',num2str(scanno,'%d'),'.mat');
        save(outfilename,'puf_features');
    end
end


