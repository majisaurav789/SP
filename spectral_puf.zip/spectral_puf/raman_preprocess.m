function raman_data_new = raman_preprocess(raman_data, lpfil)

    % Removing the spike from the Raman data based on the follwing article:
    % https://towardsdatascience.com/removing-spikes-from-raman-spectra-8a9fdda0ac22

    threshold      = 20; % Parameter selected based on prior characterization.
    neighbour      = 7;  % Parameter selected based on prior characterization

    raman_z_score  = [0,diff(raman_data)];
    raman_z_score  = abs(raman_z_score - median(raman_z_score));         
    raman_z_score  = raman_z_score/median(raman_z_score);
    raman_z_score  = (raman_z_score<threshold);     
          
    raman_data_new = raman_data;
    for i = 1:size(raman_data_new,2)
        if(raman_z_score(i)==0)
            data_group        = raman_z_score((i-neighbour):(i+neighbour)).*raman_data((i-neighbour):(i+neighbour));
            data_sum          = sum(raman_z_score((i-neighbour):(i+neighbour)));
            raman_data_new(i) = sum(data_group)/data_sum;
        end
    end
    raman_data_new  = filtfilt(lpfil,raman_data_new);
    raman_data_new  = raman_data_new - min(raman_data_new);
end

