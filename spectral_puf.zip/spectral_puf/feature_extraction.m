function feature_out = feature_extraction(raman_data)

        a_1665      = 100:200;
        I_1665      = max(raman_data(a_1665));

        %%% Feature 0: (I_0905 - I_0950)/I_1665
        a_0905      = 860:868; I_0905 = max(raman_data(a_0905));
        a_0950      = 820:850; I_0950 = max(raman_data(a_0950)); 
        feature0    = (I_0905-I_0950)/I_1665;

        %%% Feature 1: (I_0975 - I_1005)/I_1665
        a_0975      = 790:810; I_0975 = max(raman_data(a_0975));
        a_1005      = 770:790; I_1005 = max(raman_data(a_1005));
        feature1    = (I_0975-I_1005)/I_1665;

        %%% Feature 2: I_1260/I_1230
        a_1230      = 500:600; I_1230 = max(raman_data(a_1230));
        i_1260      = 545;     I_1260 = raman_data(i_1260); 
        feature2    = I_1260/I_1230;

        %%% Feature 3: I_1665
        feature3    = I_1665; 

        feature_out = [feature0,feature1,feature2,feature3];
end
