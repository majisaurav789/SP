clear; clc;
% This code lowpass filters the Raman spectra for each seed, scan and area.
% It then extracts the 4 features from the Ramn spectra to be used for PUF. 
SEED         = 30;
SCANNO       = 2;
AREANO       = 16;
puf_features = zeros(AREANO,4);

% This lowpass filter is optimized based on prior characterization:
load('filter_lowpass.mat');

for seedno = 1:SEED
    for scanno = 1:SCANNO
        for areano = 1:AREANO
            matfilename = strcat('raman_data/seed',num2str(seedno,'%02d'),'_scan',num2str(scanno,'%01d'),'_area',num2str(areano-1,'%02d'),'.mat');
            load(matfilename);

            raman_data_new = raman_preprocess(raman_data,lpfil);
            raman_features  = feature_extraction(raman_data_new);
            puf_features(areano,:) = raman_features;
            
        end
        outfilename = strcat('puf_features/puf_features_seed',num2str(seedno,'%02d'),'_scan',num2str(scanno,'%d'),'.mat');
        save(outfilename,'puf_features');
    end
end    
