clear; clc;
% This script obtains the PUF codes for 30 seeds (each equipped with 10
% challenges).
SEED = 30;  %No. of seeds
L    = 128; %Bits of PUF Response
addpath('aes/');

% Generating the Random Challenge:
cipher_key     =  '000102030405060708090a0b0c0d0e0f';
authentication_challenge_array = [...
                  '00112233445566778899aabbccddeeff';...
                  '9ad9b465c689d1a16acc4ab2e106f183';...
                  '093deebd940b652aca550d4618760f1a';...
                  '946ff856c593c65ffb8ffa30e986acd8';...
                  'b43846330541606e77f98d199254591b';...
                  '3b1feb57fa1efd3840d0d1e7cb7710e2';...
                  '88ddf9c72bf64224020cc790dc148cff';...
                  '353fa1d66861d8380f2de4aa0992c002';...
                  '63c9082414d600212ab8ba40993fc0f2';...
                  'c1e89eb9014c1d03cc2cfb048686bf21'];
C                   = size(authentication_challenge_array,1);
puf_challenge_array = zeros(C,L);
for iter = 1:C
    authentication_challenge    = authentication_challenge_array(iter,:);
    puf_challenge_array(iter,:) = generate_pufchallenge(cipher_key,authentication_challenge);
end
clear authentication_challenge iter;

% Computing the PUF Responses:
puf_response   = zeros(SEED*C,L);
for seedno = 1:SEED
    filename = strcat('puf_features/puf_features_seed',num2str(seedno,'%02d'),'_scan1.mat');
    load(filename);
    for challenge = 1:C
        puf_response((seedno-1)*C+challenge,:) = compute_pufresponse(puf_features,puf_challenge_array(challenge,:));
    end 
end
clear challenge filename puf_features seedno;

% PRINTING THE PUF CODES FOR RANDOMNESS TEST:
% Paste the codes in Python for PUF Verification.
fprintf("#SPECTRAL %d PUF CODES (FOR %d SEEDS)\n",SEED*C,SEED);
fprintf("result = zeros((%d,8))\n",SEED*C)
for x = 1:(SEED*C)
    fprintf("puf = '");
    puf = squeeze(puf_response(x,:));
     for z = 1:size(puf,2)
        fprintf('%d',puf(z));
     end
     fprintf("'; ");
     fprintf(" result[%d] = test_nist(puf);\n",x-1);
end 
fprintf("print_nist_result_summary(result)\n");  
clear puf x z;
save('puf_response/PUF_300.mat','puf_challenge_array','puf_response');
