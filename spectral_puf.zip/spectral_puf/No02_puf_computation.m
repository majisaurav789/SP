clear; clc;
% This script generates the PUF challenge from the cipher_key and the
% authentication_challenge. It computes the PUF responses for all the 
% 30 seeds and 2 scans.

addpath('aes/');

SEED                     = 30;
SCAN                     = 2;
L                        = 128;

cipher_key               = '000102030405060708090a0b0c0d0e0f';
authentication_challenge = '00112233445566778899aabbccddeeff';

% Generating the PUF Challenge:
puf_challenge  = generate_pufchallenge(cipher_key,authentication_challenge);

% Computing the PUF Responses:
puf_response   = zeros(SEED,SCAN,L);
for seedno = 1:SEED
    for scanno = 1:SCAN
        filename = strcat('puf_features/puf_features_seed',num2str(seedno,'%02d'),'_scan',num2str(scanno,'%d'),'.mat');
        load(filename);
        puf_response(seedno,scanno,:) = compute_pufresponse(puf_features,puf_challenge);
    end 
end
save('puf_response/PUF_30x2.mat','puf_challenge','puf_response');
