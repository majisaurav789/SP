function puf_response = compute_pufresponse(puf_features,puf_challenge)
    L            = size(puf_challenge,2); 
    puf_response = zeros(1,L);
    for iter = 1:L
        challenge          = puf_challenge(iter);
        area_a             = (mod(challenge,1024)-mod(challenge,64))/64;
        area_b             = (mod(challenge,64  )-mod(challenge,4 ))/4;
        select             = mod(challenge,4); 
        puf_response(iter) = puf_features(area_a+1,select+1)>puf_features(area_b+1,select+1);
    end  
end

