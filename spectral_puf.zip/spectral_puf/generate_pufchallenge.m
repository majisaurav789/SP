function challenge = generate_pufchallenge(cipher_key,authentication_challenge)
    
    L         = 128; %No. of blocks present in the challenge.
    J         = 10;  %No. of bits in each challenge block.
    challenge = zeros(1,L);

    % Expansion of the "Authentication Challenge":
    cipher = authentication_challenge;
    for iter = 1:J
        cipher     = Cipher(cipher_key,cipher);
        for y = 1:(L/4)
            cipher_bin       = dec2bin(hex2dec(cipher(y)),4);
            challenge(4*y-3) = 2*challenge(4*y-3) + (cipher_bin(1)=='1');
            challenge(4*y-2) = 2*challenge(4*y-2) + (cipher_bin(2)=='1');
            challenge(4*y-1) = 2*challenge(4*y-1) + (cipher_bin(3)=='1');
            challenge(4*y-0) = 2*challenge(4*y-0) + (cipher_bin(4)=='1');
        end
    end

    % Post-processing of the "Challenge":
    for iter = 1:L
        
        area_a = (mod(challenge(iter),1024)-mod(challenge(iter),64))/64;
        area_b = (mod(challenge(iter),64  )-mod(challenge(iter),4 ))/4;
        select = mod(challenge(iter),4); 

        if(area_a==area_b)
            if(mod(area_a,2)==0)
                area_b = area_b + 1;
            else
                area_b = area_b - 1;
            end
        end
        challenge(iter) = (area_a*64) + (area_b*4) + select;
    end
end

